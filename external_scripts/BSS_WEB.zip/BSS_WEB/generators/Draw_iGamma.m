function y = Draw_iGamma(a,b)

% Generate Inverse Gamma random draws

y = inv(gamrnd(a,1/b));